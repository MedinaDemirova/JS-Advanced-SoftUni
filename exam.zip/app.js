const fbAuth = firebase.auth();
const fbDatabase = firebase.firestore();

const app = Sammy('#container', function (context) {
    this.use('Handlebars', 'hbs');

    // Home
    this.get('/home', function (context) {

        fbDatabase.collection('destinations')
            .get()
            .then(response => {
                context.destinations = [];
                response.forEach(element => {
                    context.destinations.push({ id: element.id, ...element.data() })
                });
                extandContext(context)
                    .then(function () {
                        this.partial('./templates/home.hbs');
                    });
            })
            .catch(err => {
                console.log(err)
            });
    });

    //Register 
    this.get('/register', function (context) {
        extandContext(context)
            .then(function () {
                this.partial('./templates/register.hbs');
            });
    });

    this.post('/register', function (context) {
        console.log(context)
        let { email, password, rePassword } = context.params;

        if (password == rePassword && email.match(/[\w]+@[\w]+\.[A-Za-z]+/)) {
            fbAuth.createUserWithEmailAndPassword(email, password)
                .then((userData) => {
                    fbAuth.signInWithEmailAndPassword(email, password)
                        .then((userData) => {
                            saveUserData(userData);
                            this.redirect('#/home');
                        })
                        .catch(err => {
                            console.log(err)
                        });
                })
                .catch(err => {
                    console.log(err);
                });
        } else {
            console.log('error');
            this.redirect("#/register");
        };


    });


    //Login
    this.get('/login', function (context) {
        extandContext(context)
            .then(function () {
                this.partial('./templates/login.hbs');
            });
    });

    this.post('/login', function (context) {
        console.log(context)
        let { email, password } = context.params;

        fbAuth.signInWithEmailAndPassword(email, password)
            .then((userData) => {
                saveUserData(userData);

                this.redirect('#/home');
            })
            .catch(err => {
                console.log(err)
                this.redirect("#/login")
            });
    });

    //Logout
    this.get('/logout', function (context) {
        fbAuth.signOut()
            .then((response) => {
                clearUserData();
                this.redirect('#/home');
            })
            .catch(err => {
                console.log(err)
            })
    });

    //Create destination
    this.get('/create', function (context) {
        extandContext(context)
            .then(function () {
                this.partial('./templates/create.hbs');
            });
    });

    this.post('/create', function (context) {
        let { destination, city, imgUrl, duration, departureDate } = context.params;
       
        if (destination !== '' && city !== '' && imgUrl !== '' && duration !== '' && departureDate !== '') {

            fbDatabase.collection("destinations").add({
                destination, city, duration, departureDate, creator: getUserData().email, imgUrl
            })
                .then(createdData => {
                    console.log(createdData);
                    this.redirect('#/home');
                })
                .catch(err => {
                    console.log(err)
                });
        }
    });

    //Details
    this.get('/details/:currentID', function (context) {
        const { currentID } = context.params;
        console.log(context.params)
        fbDatabase.collection(`destinations`).doc(currentID).get()
            .then(response => {
                let destinationData = response.data();
                let iAmCreator = Boolean(destinationData.creator == getUserData().email)
                console.log(iAmCreator)
                context.destination = { ...destinationData, id: currentID, iAmCreator };
                extandContext(context)
                    .then(function () {
                        this.partial('./templates/details.hbs');
                    });
            });
    });

    //Edit destination

    this.get('/edit/:currentID', function (context) {
        const { currentID } = context.params;

        fbDatabase.collection('destinations').doc(currentID).get()
            .then((response) => {
                console.log(currentID)
                context.destination = { id: currentID, ...response.data() }
                extandContext(context)
                    .then(function () {
                        this.partial('./templates/edit.hbs');
                    });
            })
            .catch(err=> console.log (err));
    });


    this.post('/edit/:currentID', function (context) {
        const { destination, city, duration, imgUrl, departureDate, iAmCreator,currentID } = context.params;
        if (destination !== '' && city !== '' && imgUrl !== '' && duration !== '' && departureDate !== '') {

        fbDatabase.collection('destinations').doc(currentID).get()
            .then((response) => {

                fbDatabase.collection('destinations').doc(currentID)
                    .set({ ...response.data(), destination, city, currentID, imgUrl, duration, departureDate, currentID })
                    .then((response) => {
                        this.redirect(`#/details/${currentID}`);
                    })
                    .catch(err => console.log(err));
            })
            .catch(err => console.log(err));
        };
    });


    //My destinations
    this.get('/mydestinations', function (context) {

        fbDatabase.collection('destinations')
            .get()
            .then(response => {
                context.user = getUserData().email;
                context.mydestinations = [];
                response.forEach(element => {
                    console.log(element.data())
                    let actualData = element.data();
                    let iAmCreator = Boolean(actualData.creator == getUserData().email)
                    console.log(actualData)
                    if (iAmCreator) {
                        context.mydestinations.push({actualData,id:element.id })
                        console.log(context.mydestinations)
                    }
                });
                extandContext(context)
                    .then(function () {
                        this.partial('./templates/mydestinations.hbs');
                    });
            })
            .catch(err => {
                console.log(err)
            });


    });


    //Delete post
    this.get('/delete/:currentID', function (context) {
        const { currentID } = context.params;
        console.log(context.params)
        fbDatabase.collection(`destinations`).doc(currentID).delete()
            .then(responce => {
                this.redirect('#/mydestinations')
            })
            .catch(err => console.log(err))
    });

});

(() => {
    app.run();
})();

function extandContext(context) {
    let user = getUserData();
    context.loggedIn = Boolean(user);
    context.userEmail = user ? user.email : '';

    return context.loadPartials({
        'header': './common/header.hbs',
        'footer': './common/footer.hbs'

    })
};

function saveUserData(userData) {
    let { user: { email, uid } } = userData;

    localStorage.setItem('user', JSON.stringify({ email, uid }));
};

function getUserData() {
    let user = localStorage.getItem('user');
    if (user) {
        return JSON.parse(user);
    } else {
        return null;
    }
};

function clearUserData() {
    localStorage.removeItem('user');
}

